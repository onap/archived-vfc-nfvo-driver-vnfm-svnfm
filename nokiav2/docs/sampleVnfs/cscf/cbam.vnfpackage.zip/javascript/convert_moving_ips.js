for(i=0; i < $.stack_params.cbam.extensions.lb_vnic_count; i++) {
    var cpd = "lbMovingCpdeth" + i
    if(cpd in  $.stack_params.cbam.externalConnectionPoints) {
        $.stack_params.cbam.externalConnectionPoints[cpd].ip_addresses = []
        for(j=0; j < $.stack_params.cbam.externalConnectionPoints[cpd].addresses.length; j++) {
            ip = $.stack_params.cbam.externalConnectionPoints[cpd].addresses[j].ip
            $.stack_params.cbam.externalConnectionPoints[cpd].addresses[j] = { ip_address: ip }
        }
    }
}

for(i=0; i < 2; i++) {
    var cpd = "oamMovingCpdeth" + i
    if(cpd in  $.stack_params.cbam.externalConnectionPoints) {
        $.stack_params.cbam.externalConnectionPoints[cpd].ip_addresses = []
        for(j=0; j < $.stack_params.cbam.externalConnectionPoints[cpd].addresses.length; j++) {
            ip = $.stack_params.cbam.externalConnectionPoints[cpd].addresses[j].ip
            $.stack_params.cbam.externalConnectionPoints[cpd].addresses[j] = { ip_address: ip }
        }
    }
}

return $.stack_params
