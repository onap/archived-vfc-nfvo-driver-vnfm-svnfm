var keys = Object.keys($.nfv_model.zones)
n = keys.length;
if(n > 0) {
    for(var aspectGroupId in $.stack_params.cbam.resources.cscf_group) {
        id = parseInt(aspectGroupId)
        if(!isNaN(id)) {
            $.stack_params.cbam.resources.cscf_group[id].cscf01.azId = $.nfv_model.zones[keys[parseInt(id) % n]].zoneId
            if('cscf02' in $.stack_params.cbam.resources.cscf_group[id]) {
                $.stack_params.cbam.resources.cscf_group[id].cscf02.azId = $.nfv_model.zones[keys[parseInt(id) % n]].zoneId
            }
        }
    }
    for(var aspectGroupId in $.stack_params.cbam.resources.tdcore_group) {
        id = parseInt(aspectGroupId)
        if(!isNaN(id)) {
            $.stack_params.cbam.resources.tdcore_group[id].tdcore01.azId = $.nfv_model.zones[keys[parseInt(id) % n]].zoneId
            if('tdcore02' in $.stack_params.cbam.resources.tdcore_group[id]) {
                $.stack_params.cbam.resources.tdcore_group[id].tdcore02.azId = $.nfv_model.zones[keys[parseInt(id) % n]].zoneId
            }
        }
    }
    $.stack_params.cbam.resources.lb01.server.azId = $.nfv_model.zones[keys[0 % n]].zoneId
    $.stack_params.cbam.resources.lb02.server.azId = $.nfv_model.zones[keys[1 % n]].zoneId
    $.stack_params.cbam.resources.oam01.server.azId = $.nfv_model.zones[keys[0 % n]].zoneId
    $.stack_params.cbam.resources.oam02.server.azId = $.nfv_model.zones[keys[1 % n]].zoneId
    if('oam03' in $.stack_params.cbam.resources) {
    	$.stack_params.cbam.resources.oam03.server.azId = $.nfv_model.zones[keys[2 % n]].zoneId
	}
    if('ld01' in $.stack_params.cbam.resources) {
	    $.stack_params.cbam.resources.ld01.server.azId = $.nfv_model.zones[keys[0 % n]].zoneId
	    $.stack_params.cbam.resources.ld02.server.azId = $.nfv_model.zones[keys[1 % n]].zoneId
	}
    if('cdi01' in $.stack_params.cbam.resources) {
    	$.stack_params.cbam.resources.cdi01.server.azId = $.nfv_model.zones[keys[0 % n]].zoneId
    	$.stack_params.cbam.resources.cdi02.server.azId = $.nfv_model.zones[keys[1 % n]].zoneId
	}


} else {
    throw "There's not enough zones available for this operation! Check instantiation parameters!"
}
return $.stack_params
