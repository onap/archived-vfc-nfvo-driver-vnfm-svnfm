#!/usr/bin/env python
# Author : Anand Nayak (anand.nayak@nokia.com)
# Implementation for CBAM environemnt file generation for
#                   CSCF roles(all/si/hc_si/hc_all/hc_nk_si/hc_nk_all)
#
import requests
import re
import socket
import xml.etree.ElementTree as etree
import sys
import StringIO
import argparse
import os
import json
import pprint
import struct
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
import logging
import datetime
logging.getLogger('requests.packages.urllib3.connectionpool').setLevel(logging.ERROR)
logger = logging.getLogger()
logger.setLevel(logging.INFO)
TIMESTAMP = datetime.datetime.today().strftime("%Y_%m_%d_%H%M%S")
LOG_FILE = os.path.basename(sys.argv[0]).split('.')[0] + '_' + TIMESTAMP + '.log'
handler = logging.FileHandler(LOG_FILE)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
# urllib3.disable_warnings()
cloud_params = {
    "zones": [
        {
      "resourceId": "<zone1>",
      "id": "zoneInfoId1"
      },
      {
      "resourceId": "<zone2>",
      "id": "zoneInfoId2"
      }
    ],
    "flavourId": "",
    "grantlessMode": True,
    "softwareImages": [
        {
            "vnfdSoftwareImageId": "cscfImage",
            "resourceId": "<CSCFIMAGE>"
        },
        {
            "vnfdSoftwareImageId": "oamImage",
            "resourceId": "<OAMIMAGE>"
        }
    ],
    "vims": [
        {
            "accessInfo": {
                "username": "<username>",
                "password": "<password>",
                "tenant"  : "<tenant name>"
            },
            "interfaceEndpoint": "<keystone uri>",
            "id": "os",
            "interfaceInfo": {
                "region": "<region name>"
            }
        }
    ]
}

cloud_flavours_cscf = {
    "computeResourceFlavours": [
        {
            "vnfdVirtualComputeDescId": "cscfCompute",
            "resourceId": "<CSCFFLAVOUR>"
        },
        {
            "vnfdVirtualComputeDescId": "lbCompute",
            "resourceId": "<LBFLAVOUR>"
        },
        {
            "vnfdVirtualComputeDescId": "oamCompute",
            "resourceId": "<OAMFLAVOUR>"
        }
    ]
}

cloud_flavour_hc_cscf = {
    "computeResourceFlavours": [
       {
            "vnfdVirtualComputeDescId": "cscfCompute",
            "resourceId": "<CSCF>"
        },
        {
            "vnfdVirtualComputeDescId": "tdcoreCompute",
            "resourceId": "<TDCORE>"
        },
        {
            "vnfdVirtualComputeDescId": "tdgmCompute",
            "resourceId": "<TDGM>"
        },
                {
            "vnfdVirtualComputeDescId": "tddiaCompute",
            "resourceId": "<TDDIA>"
        },
        {
            "vnfdVirtualComputeDescId": "l2tdCompute",
            "resourceId": "<CSCFL2TD>"
        },
        {
            "vnfdVirtualComputeDescId": "cifCompute",
            "resourceId": "<CSCFCIF>"
        },
        {
            "vnfdVirtualComputeDescId": "oamCompute",
            "resourceId": "<IMSOAM>"
        }
    ]
}

cloud_flavour_hc_nk_cscf = {
        "computeResourceFlavours": [
        {
            "vnfdVirtualComputeDescId": "cscfCompute",
            "resourceId": "<CSCF>"
        },
        {
            "vnfdVirtualComputeDescId": "tdcoreCompute",
            "resourceId": "<TDCORE>"
        },
        {
            "vnfdVirtualComputeDescId": "tdgmCompute",
            "resourceId": "<TDGM>"
        },
                {
            "vnfdVirtualComputeDescId": "tddiaCompute",
            "resourceId": "<TDDIA>"
        },
        {
            "vnfdVirtualComputeDescId": "l2tdCompute",
            "resourceId": "<CSCFL2TD>"
        },
        {
            "vnfdVirtualComputeDescId": "cdiCompute",
            "resourceId": "<CSCFCDI>"
        },
        {
            "vnfdVirtualComputeDescId": "cifCompute",
            "resourceId": "<CSCFCIF>"
        },
        {
            "vnfdVirtualComputeDescId": "oamCompute",
            "resourceId": "<IMSOAM>"
        }
    ]
}

EXTENSION_FILE = "cbam_extension.json"
INPUT_FILE = "cbam_input.json"
DEBUG = False

proto = "https"
repo_ip = ""
repo_port = 8051
dn = ""
du = ""
roles = ""
username = 'cmadmin'
password = 'yt_xk39b'


# vapp information
internal_network_ipversion = 4
internal_network_cidr = ""
vapp = {}
ip_config = {}

# NE info
vms = {}
vm_ids = {}
cscf_iface_list = ""
lb_iface_list = ""
cif_iface_list = ""
oam_iface_list = ""
cdi_iface_list = ""
l2td_iface_list = ""
tdcore_iface_list = ""
cscf_ip_details = []
lb_ip_details = []
cif_ip_details = []
l2td_ip_details = []
oam_ip_details = []
cdi_ip_details = []
no_of_cscf = 0
no_of_tdcore = 0
no_of_tdgm = 0
no_of_tddia = 0
aif = {}
enable_aif = "yes"
enable_tddia = "no"
node = ""
CSCF_DPDK_LAN = ""
LB_DPDK_LAN = ""
L2TD_DPDK_LAN = ""

def natural_sort(l):
    convert = lambda text: int(text) if text.isdigit() else text
    alphanum_key = lambda key: [convert(c) for c in re.split('([0-9]+)', key)]
    return sorted(l, key=alphanum_key)

def get_metadata_response():
    url = 'https://%s:8051/api/DU/getmetadata?purpose=create&DUName=%s/%s' % (repo_ip, dn, du)
    # print url
    if DEBUG: pprint.pprint(url)
    try:
        response = requests.get(url, verify=False, auth=(username, password))
    except Exception as e:
        print "Failed to get the cmrepo data: %s" % (str(e))
        sys.exit(1)
    
    # API result is XML data
    # JSON is returned in case of error
    try:
        json.loads(response.text)
        pprint.pprint(response.text)
    except: # json parse failed, hence no error
        return response.text
    sys.exit(1)

def join_tables(table1, table2, key1, key2):
    for row1 in table1:
        for row2 in table2:
            if key1 in row1 and key2 in row2:
                if row1[key1] == row2[key2]:
                    row = dict()
                    row = row1
                    for key in row2:
                        row[key] = row2[key]
                    yield row

def get_table(node, comp, param, cols=None):
    url = "https://%s:%s/api/v1/dn/%s/dus/%s/Release/%s/nodes/%s?Comp=%s&Param=%s" \
          % (repo_ip, repo_port, vapp['DN'], vapp['DUName'], vapp['Release'], node, comp, param)
    try:
        r = requests.get(url, verify=False, auth=(username, password))
    except Exception as e:
        print "Failed to get the cmrepo data: %s" % (str(e))
        sys.exit(1)
    resp = json.loads(r.text)
    if resp['Status'].upper() != 'SUCCESS':
        print resp
        sys.exit(1)

    rows = resp['Dus'][0]['ReleaseTag'][0]['Nodes'][0]['Comps'][0]['PMaps'][0]['ParamTable']['RowsV']
    rows_map = []
    for row in rows:
        row_map = {}
        for param in row:
            if not cols or param['Name'] in cols:
                row_map[param['Name']] = param['Value']
        rows_map.append(row_map)
    return rows_map

def get_vm_ids():
    global vm_ids
    url = "https://%s:%s/api/v1/dn/%s/dus/%s/Release/%s?Comp=cmrepo/config&Param=CE_Names" \
          % (repo_ip, repo_port, vapp['DN'], vapp['DUName'], vapp['Release'])
    try:
        r = requests.get(url, verify=False, auth=(username, password))
    except Exception as e:
        print "Failed to get the cmrepo data: %s" % (str(e))
        sys.exit(1)
    resp = json.loads(r.text)
    if resp['Status'].upper() != 'SUCCESS':
        print resp
        sys.exit(1)
    for nodetype in resp['Dus'][0]['ReleaseTag'][0]['Nodes']:
        rows = nodetype['Comps'][0]['PMaps'][0]['ParamTable']['RowsV'][0]
        for row in rows:
            if row['Name'] == "NodeType":
                key = row['Value']
            elif row['Name'] == "VmName":
                value = row['Value']
        vm_ids[key] = value

def get_deploy_params():
    global vapp
    xml = etree.parse(StringIO.StringIO(get_metadata_response()))
    root = xml.getroot()
    if root.tag.lower() == 'error':
        print root.text
        sys.exit(1)
    vapp[root.find("Information/Attribute/Key").text] = root.find("Information/Attribute/Value").text
    vapp['aif'] = {}
    for i in root.findall("ViAppConfiguration/ViAppAttributes/Attribute"):
        vapp[i.find("Key").text] = i.find("Value").text
    for i in root.findall("ViAppConfiguration/C4CAttributes/Attribute"):
        vapp['aif'][i.find("Key").text] = i.find("Value").text

    for vm in root.findall("VMs/VM"):
        name = vm.find("ID/Value").text
        vms[name] = {}
        vms[name]['aif'] = {}
        for att in vm.findall("Attributes/Attribute"):
            vms[name][att.find("Key").text] = att.find("Value").text
        for att in vm.findall("C4CAttributes/Attribute"):
            vms[name]['aif'][att.find("Key").text] = att.find("Value").text
    if DEBUG: pprint.pprint(vms)
    if DEBUG: pprint.pprint(vapp)
    logger.info("VM Details from CMRepo \n %s\n" %vms)
    logger.info("VApp Details from CMRepo%s\n" %vapp)

def get_v4prefix(netmask):
    if netmask[0] == "/" :
        return netmask[1:]
    return sum([bin(int(x)).count('1') for x in netmask.split('.')])

def get_v6prefix(netmask):
    if netmask[0] == "/":
        return netmask[1:]
    else:
        cidr_1 = netmask.split(':')
        cidr_binary = ''
        for fip in cidr_1:
            if fip != '':
                cidr_binary += bin(int(fip, 16))[2:].zfill(8)
        new_cidr = 0
        wordlist = list(cidr_binary)
        for char1 in wordlist:
            new_cidr = int(char1) + int(new_cidr)
        return(new_cidr)

def is_valid_ipv4_address(address):
    try:
        addr = socket.inet_pton(socket.AF_INET, address)
    except AttributeError: # no inet_pton here, sorry
        try:
            addr = socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error: # not a valid address
        return False

    return True

def is_valid_ipv6_address(address):
    try:
        addr= socket.inet_pton(socket.AF_INET6, address)
    except socket.error: # not a valid address
        return False
    except:
        return address.count(':') > 2
    return True

def is_valid_ip_address(address):
    try:
        if is_valid_ipv4_address(address):
            return True
        elif is_valid_ipv6_address(address):
            return True
    except:
        return False

def dpdk_enabled(node):
    global CSCF_DPDK_LAN,LB_DPDK_LAN,L2TD_DPDK_LAN
    for iface in ip_config[node]:
        # print ip_config[node][iface]['LAN_NAME']
        # raw_input()
        if roles in ['all']:
            if ip_config[node][iface]['LAN_NAME'] == LB_DPDK_LAN:
                return True
        if roles in ['hc_si','hc_nk_si','hc_all','hc_nk_all']:
            if ip_config[node][iface]['LAN_NAME'] == L2TD_DPDK_LAN:
                return True
        if ip_config[node][iface]['LAN_NAME'] == CSCF_DPDK_LAN:
            return True
    return False

def get_ip_config():
    global ip_config
    ip_config = {}
    for vm in vm_ids:
        node = vm_ids[vm]
        ip_config[node] = {}
        lan_table = get_table(vms[node]['Uuid'], "platform/cframe", "LAN", ["PRIMARY_INTERFACE", "LAN_NAME",
                                                                              "BASE_ADDRESS", "NETMASK","MTU_SIZE"])
        ip_table = get_table(vms[node]['Uuid'], "platform/cframe", "IP_NODE_CONFIG", ["IPALIAS_ADDRESS", "LAN_NAME",
                                                                                         "PHYSICAL_ADDRESS"])
        for row in join_tables(lan_table, ip_table, "LAN_NAME", "LAN_NAME"):
            iface = row['PRIMARY_INTERFACE']
            if iface not in ip_config[node]:
                ip_config[node][iface] = {}
                ip_config[node][iface]['IPALIAS'] = []
                ip_config[node][iface]['ipv4'] = {}
                ip_config[node][iface]['ipv6'] = {}
                ip_config[node][iface]['LAN_NAME'] = row['LAN_NAME']
            if is_valid_ipv4_address(row['PHYSICAL_ADDRESS']):
                ip_config[node][iface]['ipv4']['IP'] = str(row['PHYSICAL_ADDRESS'])
                ip_config[node][iface]['ipv4']['NETMASK'] = str(row['NETMASK'])
                ip_config[node][iface]['ipv4']['CIDR'] = str("%s/%s" % (row['BASE_ADDRESS'], get_v4prefix(row['NETMASK'])))
                if 'MTU_SIZE' in row: ip_config[node][iface]['MTU_SIZE'] = row['MTU_SIZE']
            if is_valid_ipv6_address(row['PHYSICAL_ADDRESS']):
                ip_config[node][iface]['ipv6']['IP'] = str(row['PHYSICAL_ADDRESS'])
                ip_config[node][iface]['ipv6']['NETMASK'] = str(row['NETMASK'])
                ip_config[node][iface]['ipv6']['CIDR'] = str("%s/%s" % (row['BASE_ADDRESS'], get_v6prefix(row['NETMASK'])))
            ip_config[node][iface]['IPALIAS'].append(str(row['IPALIAS_ADDRESS']))
    logger.info("IP Details of vms : \n %s" %ip_config)

def number_occurance(netype):
    count = 0
    for vm in vm_ids.keys():
        if netype in vm:
            count = count + 1

    if count > 1:
        return count 
    else:
        print "%s not found" %netype
        # sys.exit(1) 

def query_yes_no(question, default="yes"):
    """Ask a yes/no question via raw_input() and return their answer.
    The "answer" return value is True for "yes" or False for "no".
    """
    valid = {"yes": True, "y": True,
             "no": False, "n": False}
    if default is None:
        prompt = " [y/n] "
    elif default == "yes":
        prompt = " [Y/n] "
    elif default == "no":
        prompt = " [y/N] "
    else:
        raise ValueError("invalid default answer: '%s'" % default)

    while True:
        sys.stdout.write(question + prompt)
        choice = raw_input().lower()
        if default is not None and choice == '':
            return valid[default]
        elif choice in valid:
            return valid[choice]
        else:
            sys.stdout.write("Please respond with 'yes' or 'no' "
                             "(or 'y' or 'n').\n")

def get_mos(vm):
    mo = {}
    if 'MO_1' in vm and vm['MO_1'] == 'CAFEM-1':
        mo['tspProcessNodePort'] = vm['MO_1_tspProcessNodePort']
        mo['tspProcessNodeHTTPMode'] = vm['MO_1_tspProcessNodeHTTPMode']
        mo['cafTraceHTTPMode'] = vm['MO_1_cafTraceHTTPMode']
        mo['cafTracePort'] = vm['MO_1_cafTracePort']

    if 'MO_2' in vm and vm['MO_2'] == 'DYNADAPTATION-1':
        mo['da_metaDir'] = vm['MO_2_metaDir']
        mo['workingMode'] = vm['MO_2_workingMode']
        mo['da_port'] = vm['MO_2_port']
    
    if 'MO_4' in vm and vm['MO_4'] == 'NE3SWS-1':
        mo['securityMode'] = vm['MO_4_securitymode']
        mo['ipVersion'] = vm['MO_4_ipVersion']
        mo['http_port'] = vm['MO_4_httpPort']
        mo['https_port'] = vm['MO_4_httpsPort']

    if 'MO_5' in vm and vm['MO_5'] == 'SSH-1':
        mo['ssh_port'] = vm['MO_5_port']

    if 'MO_6' in vm and vm['MO_6'] == 'FEESERVLET-1':
        mo['FEE_Emergency_Call_Port'] = vm['MO_6_EmergencyCallPort']
        mo['hostName'] = vm['MO_6_hostName']
        mo['FEE_Transcoding_Port'] = vm['MO_6_TranscodingPort']

    return mo


def get_aif():
    global aif,node
    aif['netact'] = {}
    aif['netact_port'] = 22
    aif['netact_user'] = "omc"
    aif['netact_adaptation_release'] = vapp['aif']['Release']
    aif['netact_ne_type'] = vapp['aif']['class']
    if roles in ["hc_nk_si","hc_nk_all"]:
        aif['da_port'] = 22
        aif['da_metaDir'] = "/global/esymac/Ines_o2ml"
    else:
        aif['RootDN'] = vapp['aif']['RootDN']
    
    for vm in vms:
        if node == 'nodename':
            node_name = vms[vm]['NodeName']
        else:
            node_name = vm
        aif['netact'][node_name] = get_mos(vms[vm]['aif'])

        # global class, adaptation is CSCF
        # OAM nodes will have their own specific at VM level
        if 'class' in vms[vm]['aif']:
            aif['netact'][node_name]['netact_ne_type'] = vms[vm]['aif']['class']
        else:
            aif['netact'][node_name]['netact_ne_type'] = vapp['aif']['class']

        if 'adaptation' in vms[vm]['aif']:
            aif['netact'][node_name]['adaptation'] = vms[vm]['aif']['adaptation']
        else:
            aif['netact'][node_name]['adaptation'] = vapp['aif']['adaptation']

        if aif['netact'][node_name]['netact_ne_type'] == "IMSOAM":
            if not vm.startswith('IMSOAM-'):
                aif['netact'][node_name]['netact_instancename'] = "IMSOAM-" + vm
            else: 
                aif['netact'][node_name]['netact_instancename'] =  vm
        elif aif['netact'][node_name]['netact_ne_type'] == "CSCF":
            if not vm.startswith('CSCF-'):
                aif['netact'][node_name]['netact_instancename'] = "CSCF-" + vm
            else: 
                aif['netact'][node_name]['netact_instancename'] = vm
        aif['netact'][node_name]['ne_hostname'] = vms[vm]['aif']['hostName']

def ask_cloud_user_inputs():
    global aif,enable_aif
    e = dict()
    user_inputs = ['storage_availability_zone1','storage_availability_zone2','volume_type']
    netact_inputs = ['netact_address','netact_password','netact_mrname','netact_plmn']
    if roles in ["hc_nk_si","hc_nk_all"]:
            netact_inputs.append('ipVersion')
    for user_input in user_inputs:
        while True:
            print "Enter the %s" %user_input
            value = raw_input().strip('\n')
            if value:
                break
            else:
                print "!!!ERROR:Enter the non empty Availability zone name"
        e[user_input] = value

    if query_yes_no("Enable netact aif?"):
        enable_aif = 'yes'
        for netact_input in netact_inputs:   
            while True:         
                if netact_input == "ipVersion":
                    print "Enter the %s[IPv4,IPv6]" %netact_input
                else:                
                    print "Enter the %s" %netact_input
                value = raw_input().strip('\n')
                if netact_input == "ipVersion" and value == "IPv4":      
                    aif[netact_input] = "0"
                    break
                elif netact_input == "ipVersion" and value == "IPv6":
                    aif[netact_input] = "1"
                    break
                elif  netact_input == "ipVersion" and value not in ["IPv4","IPv6"]:
                    continue
                elif netact_input == "netact_address":
                    if is_valid_ip_address(value):      
                        aif[netact_input] = value
                        break
                else:
                    aif[netact_input] = value
                    break
        if roles in ["hc_nk_si","hc_nk_all"]:  
            if query_yes_no("Enable the security mode for NETACT?"):
                aif['https_port'] = 8443
                aif['securityMode'] = "1"
            else: 
                aif['securityMode'] = "0"
                aif['http_port'] = 8080
    else:
        enable_aif = 'no'
    return e

def ask_l2td_internal_cipa_userinput():
    while True:
        print "Enter the l2td_internal_cipa_ip"
        value = raw_input().strip('\n')
        if value:
            break
        else:
            print "!!!ERROR:Enter the non empty ip address"
    return value

def internal_network_dpdk_cidr():
    global CSCF_DPDK_LAN
    e = dict()
    if roles == 'all':
        dpdk_node = 'CSCF1'
    elif roles in ["hc_all","hc_si","hc_nk_si","hc_nk_all"]:
        dpdk_node = 'TD_Core1'

    if dpdk_enabled(vm_ids[dpdk_node]):
        if internal_network_ipversion == 6:
            for interface in ip_config[vm_ids[dpdk_node]].keys():
                if ip_config[vm_ids[dpdk_node]][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
                    e['internal_network_dpdk_cidr'] = ip_config[vm_ids[dpdk_node]][interface]['ipv6']['CIDR']
        else:
            for interface in ip_config[vm_ids[dpdk_node]].keys():
                if ip_config[vm_ids[dpdk_node]][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
                    e['internal_network_dpdk_cidr'] = ip_config[vm_ids[dpdk_node]][interface]['ipv4']['CIDR']
    return e

def search_if_ip_exists(ip):
    for vm in ip_config.keys():
        if internal_network_ipversion == 4:
            if ip in ip_config[vm]['eth0']['ipv4']['IP']:
                return True
        else:
            if ip in ip_config[vm]['eth0']['ipv6']['IP']:
                return True
    return False

#Work Around to generate the L2TD internal_cipa ip address
def calculate_l2td_internal_cipa_ip(internal_network_cidr):
    prefix = int(internal_network_cidr.split('/')[1])
    internal_network = internal_network_cidr.split('/')[0]
    if internal_network_ipversion == 4:
        last_octet = 32 - prefix
        if last_octet > 8:
            last_octet = 8
        last_octet = pow(2,last_octet) - 2
        ip = internal_network.rsplit(".", 1)
        for i in range(20):
            ip[-1] = str(last_octet) 
            if not (search_if_ip_exists(".".join(ip))):
                break
            ip[-1] = str(last_octet - 1)
            if i == 20: return(ask_l2td_internal_cipa_userinput())
        return ".".join(ip)
    else:
        last_hex = 128 - prefix
        if last_hex > 16:
            last_hex = 16
        last_hex = pow(2,last_hex) - 2
        ip = internal_network.rsplit(":", 1)
        ip[-1] = '{:x}'.format(last_hex)
        for i in range(20):
            ip[-1] = str(last_hex) 
            if not (search_if_ip_exists(":".join(ip))):
                break
            last_hex = last_hex - 1
            ip[-1] = '{:x}'.format(last_hex) 
            if i == 20: return(ask_l2td_internal_cipa_userinput())
        return ":".join(ip)

def common_extension_parameters():
    global node,enable_aif,internal_network_ipversion,internal_network_cidr,enable_aif,CSCF_DPDK_LAN,LB_DPDK_LAN,L2TD_DPDK_LAN
    e = dict()
    e = {
           'vnf_name'                   : vapp['Application'],
            'dn'                        : vapp['DN'],
            'du'                        : vapp['DUName'],
            'oam01_internal_ip'         : vms[vm_ids['OAMUnit']]['NodeIp'],
            'oam02_internal_ip'         : vms[vm_ids['OAMUnit2']]['NodeIp'],
            'oam03_internal_ip'         : vms[vm_ids['OAMUnit3']]['NodeIp'],
            'oam01_uuid'                : vms[vm_ids['OAMUnit']]['Uuid'],
            'oam02_uuid'                : vms[vm_ids['OAMUnit2']]['Uuid'],
            'oam03_uuid'                : vms[vm_ids['OAMUnit3']]['Uuid'],
            'oam01_tempkey'             : '%s_TempKey'%(vms[vm_ids['OAMUnit']]['NodeName']),
            'oam02_tempkey'             : '%s_TempKey'%(vms[vm_ids['OAMUnit2']]['NodeName']),
            'oam03_tempkey'             : '%s_TempKey'%(vms[vm_ids['OAMUnit3']]['NodeName']),
            'oam01_privkey'             : '%s_PrivKey'%(vms[vm_ids['OAMUnit']]['NodeName']),
            'oam02_privkey'             : '%s_PrivKey'%(vms[vm_ids['OAMUnit2']]['NodeName']),
            'oam03_privkey'             : '%s_PrivKey'%(vms[vm_ids['OAMUnit3']]['NodeName']),
            'cakey'                     : 'ROOT_CA_Key'
        }
    if node == "nodename":
            e.update( 
                {
                   'oam01_name'                : vms[vm_ids['OAMUnit']]['NodeName'],
                   'oam02_name'                : vms[vm_ids['OAMUnit2']]['NodeName'],
                   'oam03_name'                : vms[vm_ids['OAMUnit3']]['NodeName']
                }
            )
    else:
            e.update( 
                {
                   'oam01_name'                : vm_ids['OAMUnit'],
                   'oam02_name'                : vm_ids['OAMUnit2'],
                   'oam03_name'                : vm_ids['OAMUnit3']
               }
            )
    e.update(
           {    
                'oam_cipa_ip'          : vms[vm_ids['OAMUnit']]['OamCipa'],
                'default_gateway'      : vms[vm_ids['OAMUnit']]['OamGateway'],
                'oam_internal_cipa_ip' : vms[vm_ids['OAMUnit']]['NodeCipa'],
                'oam_netmask'          : vms[vm_ids['OAMUnit']]['OamNetmask'],
                'oam_volume_size'      : 300,
                'cmrepo_ip'            : vapp['CmRepoIp'],
                'swrepo_ip'            : vapp['SwRepoIp']
           }
        )
    if "OamDnsIp"  in vapp:
        e['dns_ip'] = vapp['OamDnsIp']
    else: 
        e['dns_ip'] = ""
    e['release'] = vapp['Release']

    #Commented this code because of issue in the TPD.Internal will be calculated depending on the CIDVM  DBLAN for n+k
    # if 'IP' in ip_config[vm_ids['CSCF1']]['eth0']['ipv6'].keys() and 'IP' in ip_config[vm_ids['CSCF1']]['eth0']['ipv4'].keys():
    #     print "Dual stack is not supported"
    #     sys.exit(1)

    #Issue in the TPD,Work around given for 17.0
    if roles in ["hc_nk_si","hc_nk_all"]:
        VM = "CDI1"
        interface = "eth1"
    else:
        VM = "CSCF1"
        interface = "eth0"
    if 'IP' in ip_config[vm_ids[VM]][interface]['ipv6'].keys() and is_valid_ipv6_address(ip_config[vm_ids[VM]][interface]['ipv6']['IP']):
        CSCF_DPDK_LAN = "InternalLAN2_CSCF_IPv6"
        LB_DPDK_LAN = "InternalLAN2_LB_IPv6"
        L2TD_DPDK_LAN = "InternalLAN2_L2TD_IPv6"
        internal_network_ipversion = 6
        e['internal_network_ipversion'] = 6
        e['internal_network_cidr'] = internal_network_cidr = ip_config[vm_ids[VM]]['eth0']['ipv6']['CIDR']
        e['internal_netmask'] = ip_config[vm_ids[VM]]['eth0']['ipv6']['NETMASK']
    else:
        CSCF_DPDK_LAN = "InternalLAN2_CSCF"
        LB_DPDK_LAN = "InternalLAN2_LB"
        L2TD_DPDK_LAN = "InternalLAN2_L2TD"
        internal_network_ipversion = 4
        e['internal_network_ipversion'] = 4
        e['internal_network_cidr'] = internal_network_cidr = ip_config[vm_ids[VM]]['eth0']['ipv4']['CIDR']
        e['internal_netmask'] = ip_config[vm_ids[VM]]['eth0']['ipv4']['NETMASK']

    if internal_network_ipversion == 4:
        e['mtu'] = ip_config[vm_ids['OAMUnit']]['eth0']['MTU_SIZE']
    else:
        e['mtu'] = 1440 
    if roles not in ['si']:
        e.update(internal_network_dpdk_cidr())
    e.update(ask_cloud_user_inputs())
    e['aif'] = enable_aif
    return e

def get_lb_cif_extension_detais():
    global lb_iface_list,cif_iface_list
    e = dict()
    if roles in ['si','all']:
        loadbalancer_name = 'lb'
        loadbalancer_type = 'LB'
    else:
        loadbalancer_name = 'cif'
        loadbalancer_type = 'CIF'

    e.update ({
               '%s01_internal_ip' % loadbalancer_name          : vms[vm_ids['%s1' %loadbalancer_type]]['NodeIp'],
               '%s02_internal_ip' % loadbalancer_name          : vms[vm_ids['%s2' %loadbalancer_type]]['NodeIp'],
               '%s_internal_cipa_ip' % loadbalancer_name       : ip_config[vm_ids['%s1' %loadbalancer_type]]['eth0']['IPALIAS'][0],
               '%s_volume_size' % loadbalancer_name            : 300,
               '%s01_uuid'   %loadbalancer_name                : vms[vm_ids['%s1' %loadbalancer_type]]['Uuid'],
               '%s02_uuid'   %loadbalancer_name                : vms[vm_ids['%s2' %loadbalancer_type]]['Uuid'],
        })
    node_iface_list = '%s_iface_list' % loadbalancer_name
    globals()[node_iface_list] = natural_sort(ip_config[vm_ids['%s1' %loadbalancer_type]].keys())
    e['%s_vnic_count' %loadbalancer_name] = int(re.split('([0-9]+)', globals()[node_iface_list][-1])[1]) + 1
    if node == "nodename":
        e.update( {
                       '%s01_name' %loadbalancer_name                 : vms[vm_ids['%s1' %loadbalancer_type]]['NodeName'],
                       '%s02_name' %loadbalancer_name                 : vms[vm_ids['%s2' %loadbalancer_type]]['NodeName']
                } )
    else:
        e.update( {
                       '%s01_name' %loadbalancer_name                 :vm_ids['%s1' %loadbalancer_type],
                       '%s02_name' %loadbalancer_name                 :vm_ids['%s2' %loadbalancer_type]
                } )
    return e

def create_cscf_cbam_extension():
    global node,no_of_cscf,CSCF_DPDK_LAN,LB_DPDK_LAN
    e = dict()
    e.update(get_lb_cif_extension_detais())
    no_of_cscf = number_occurance("CSCF")    
    if dpdk_enabled(vm_ids['CSCF1']) and 'si'  not in roles:
        e['cscf_internal_ips_dpdk_first_of_pair'] = []
        e['cscf_internal_ips_dpdk_second_of_pair'] = []  
    e['cscf_internal_ips_first_of_pair'] = []
    e['cscf_internal_ips_second_of_pair'] = []
    e['cscf_names_first_of_pair'] = []
    e['cscf_names_second_of_pair'] = []
    e['cscf_uuids_first_of_pair'] = []
    e['cscf_uuids_second_of_pair'] = []
    for k in range(no_of_cscf/2):
        cscf_node1 = "CSCF%s" %(k * 2 + 1)
        cscf_node2 = "CSCF%s" %(k * 2 + 2)
        cscf01 = vm_ids[cscf_node1]
        cscf02 = vm_ids[cscf_node2]
        if dpdk_enabled(vm_ids['CSCF1']) and 'si'  not in roles:
            for interface in ip_config[cscf01].keys():
                if ip_config[cscf01][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
                        if internal_network_ipversion == 6 : 
                            e['cscf_internal_ips_dpdk_first_of_pair'].append(ip_config[cscf01][interface]['ipv6']['IP'])
                        else:
                            e['cscf_internal_ips_dpdk_first_of_pair'].append(ip_config[cscf01][interface]['ipv4']['IP'])
            for interface in ip_config[cscf02].keys():
                if ip_config[cscf02][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
                        if internal_network_ipversion == 6 : 
                            e['cscf_internal_ips_dpdk_second_of_pair'].append(ip_config[cscf02][interface]['ipv6']['IP'])
                        else:
                            e['cscf_internal_ips_dpdk_second_of_pair'].append(ip_config[cscf02][interface]['ipv4']['IP'])
            for interface in ip_config[vm_ids['LB1']].keys():
                if ip_config[vm_ids['LB1']][interface]['LAN_NAME'] == LB_DPDK_LAN:
                    if internal_network_ipversion == 6 : 
                        e['lb01_internal_dpdk_ip']    = ip_config[vm_ids['LB1']][interface]['ipv6']['IP']
                        e['lb02_internal_dpdk_ip']    = ip_config[vm_ids['LB2']][interface]['ipv6']['IP']
                        e['lb_internal_dpdk_cipa_ip'] = ip_config[vm_ids['LB1']][interface]['IPALIAS'][0]
                    else: 
                        e['lb01_internal_dpdk_ip']    = ip_config[vm_ids['LB1']][interface]['ipv4']['IP']
                        e['lb02_internal_dpdk_ip']    = ip_config[vm_ids['LB2']][interface]['ipv4']['IP']
                        e['lb_internal_dpdk_cipa_ip'] = ip_config[vm_ids['LB1']][interface]['IPALIAS'][0]

        e['cscf_internal_ips_first_of_pair'].append(vms[cscf01]['NodeIp'])
        e['cscf_internal_ips_second_of_pair'].append(vms[cscf02]['NodeIp'])
        if node == 'nodename':
            e['cscf_names_first_of_pair'].append(vms[cscf01]['NodeName'])
            e['cscf_names_second_of_pair'].append(vms[cscf02]['NodeName'])
        else:
            e['cscf_names_first_of_pair'].append(cscf01)
            e['cscf_names_second_of_pair'].append(cscf02)
        e['cscf_uuids_first_of_pair'].append(vms[cscf01]['Uuid'])
        e['cscf_uuids_second_of_pair'].append(vms[cscf02]['Uuid'])
    return e

def get_hc_ne_specific_extension_details(no_of_nodes,nodetype,extension_var_name):
    global CSCF_DPDK_LAN,L2TD_DPDK_LAN
    e = dict()
    if no_of_nodes < 1:
        print "%s NE not present..continuing" %nodetype
        return e
    
    e['%s_internal_ips_dpdk_first_of_pair' %extension_var_name] = []
    e['%s_internal_ips_dpdk_second_of_pair'%extension_var_name] = []
    e['%s_internal_ips_first_of_pair'%extension_var_name] = []
    e['%s_internal_ips_second_of_pair'%extension_var_name] = []
    e['%s_names_first_of_pair'%extension_var_name] = []
    e['%s_names_second_of_pair'%extension_var_name] = []
    e['%s_uuids_first_of_pair'%extension_var_name] = []
    e['%s_uuids_second_of_pair'%extension_var_name] = []
    for k in range(no_of_nodes/2):
        core_node1 = "%s%s" %(nodetype,k * 2 + 1)
        core_node2 = "%s%s" %(nodetype,k * 2 + 2)
        core01 = vm_ids[core_node1]
        core02 = vm_ids[core_node2]
        if dpdk_enabled(vm_ids[core_node1]):
            for interface in ip_config[core01].keys():
                if ip_config[core01][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
                        if internal_network_ipversion == 6 : 
                            e['%s_internal_ips_dpdk_first_of_pair' %extension_var_name].append(ip_config[core01][interface]['ipv6']['IP'])
                        else:
                            e['%s_internal_ips_dpdk_first_of_pair' %extension_var_name].append(ip_config[core01][interface]['ipv4']['IP'])
            for interface in ip_config[core02].keys():
                if ip_config[core02][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
                        if internal_network_ipversion == 6 : 
                            e['%s_internal_ips_dpdk_second_of_pair'%extension_var_name].append(ip_config[core02][interface]['ipv6']['IP'])
                        else:
                            e['%s_internal_ips_dpdk_second_of_pair'%extension_var_name].append(ip_config[core02][interface]['ipv4']['IP'])
        e['%s_internal_ips_first_of_pair'%extension_var_name].append(vms[core01]['NodeIp'])
        e['%s_internal_ips_second_of_pair'%extension_var_name].append(vms[core02]['NodeIp'])
        if node == 'nodename':
            e['%s_names_first_of_pair'%extension_var_name].append(vms[core01]['NodeName'])
            e['%s_names_second_of_pair'%extension_var_name].append(vms[core02]['NodeName'])
        else:
            e['%s_names_first_of_pair'%extension_var_name].append(core01)
            e['%s_names_second_of_pair'%extension_var_name].append(core02)
        e['%s_uuids_first_of_pair'%extension_var_name].append(vms[core01]['Uuid'])
        e['%s_uuids_second_of_pair'%extension_var_name].append(vms[core02]['Uuid'])
    return e

def create_hc_cscf_extension():
    global node,l2td_iface_list,no_of_tdcore,no_of_cscf,no_of_tdgm,CSCF_DPDK_LAN,L2TD_DPDK_LAN
    e = dict()
    e.update(get_lb_cif_extension_detais())
    e.update( {
    'l2td01_internal_ip'          : vms[vm_ids['L2TD1']]['NodeIp'],
    'l2td02_internal_ip'          : vms[vm_ids['L2TD2']]['NodeIp'],
    'l2td01_uuid'                 : vms[vm_ids['L2TD1']]['Uuid'],
    'l2td02_uuid'                 : vms[vm_ids['L2TD2']]['Uuid']
    })
    e['l2td_internal_cipa_ip'] = calculate_l2td_internal_cipa_ip(internal_network_cidr)
    l2td_iface_list = natural_sort(ip_config[vm_ids['L2TD1']].keys())
    e['l2td_vnic_count'] = int(re.split('([0-9]+)', l2td_iface_list[-1])[1]) + 1
    if node == 'nodename':
        e.update(
              {
                'l2td01_name'                 : vms[vm_ids['L2TD1']]['NodeName'],
                'l2td02_name'                 : vms[vm_ids['L2TD2']]['NodeName']
              })
    else:
        e.update(
              {
                'l2td01_name'                 : vm_ids['L2TD1'],
                'l2td02_name'                 : vm_ids['L2TD2']
              })

    no_of_tdcore = number_occurance("TD_Core")
    no_of_tdgm = number_occurance("TD_Gm")
    no_of_cscf = number_occurance("CSCF")

    # if dpdk_enabled(vm_ids['CSCF1']) and 'hc_si'  not in roles and no_of_tdgm == 0:
    #     e['cscf_internal_ips_dpdk_first_of_pair'] = []
    #     e['cscf_internal_ips_dpdk_second_of_pair'] = []
    e['cscf_internal_ips_first_of_pair'] = []
    e['cscf_internal_ips_second_of_pair'] = []
    e['cscf_names_first_of_pair'] = []
    e['cscf_names_second_of_pair'] = []
    e['cscf_uuids_first_of_pair'] = []
    e['cscf_uuids_second_of_pair'] = []

    for k in range(no_of_cscf/2):
        cscf_node1 = "CSCF%s" %(k * 2 + 1)
        cscf_node2 = "CSCF%s" %(k * 2 + 2)
        cscf01 = vm_ids[cscf_node1]
        cscf02 = vm_ids[cscf_node2]
        # if dpdk_enabled(vm_ids['CSCF1']) and roles not in ["hc_si","hc_all"] and no_of_tdgm == 0:
        #     for interface in ip_config[cscf01].keys():
        #         if ip_config[cscf01][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
        #                 if internal_network_ipversion == 6 : 
        #                     e['cscf_internal_ips_dpdk_first_of_pair'].append(ip_config[cscf01][interface]['ipv6']['IP'])
        #                 else:
        #                     e['cscf_internal_ips_dpdk_first_of_pair'].append(ip_config[cscf01][interface]['ipv4']['IP'])
            # for interface in ip_config[cscf02].keys():
            #     if ip_config[cscf02][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
            #             if internal_network_ipversion == 6 : 
            #                 e['cscf_internal_ips_dpdk_second_of_pair'].append(ip_config[cscf02][interface]['ipv6']['IP'])
            #             else:
            #                 e['cscf_internal_ips_dpdk_second_of_pair'].append(ip_config[cscf02][interface]['ipv4']['IP'])
        e['cscf_internal_ips_first_of_pair'].append(vms[cscf01]['NodeIp'])
        e['cscf_internal_ips_second_of_pair'].append(vms[cscf02]['NodeIp'])
        if node == 'nodename':
            e['cscf_names_first_of_pair'].append(vms[cscf01]['NodeName'])
            e['cscf_names_second_of_pair'].append(vms[cscf02]['NodeName'])
        else:
            e['cscf_names_first_of_pair'].append(cscf01)
            e['cscf_names_second_of_pair'].append(cscf02)
        e['cscf_uuids_first_of_pair'].append(vms[cscf01]['Uuid'])
        e['cscf_uuids_second_of_pair'].append(vms[cscf02]['Uuid'])
    for interface in ip_config[vm_ids['L2TD1']].keys():
        if ip_config[vm_ids['L2TD1']][interface]['LAN_NAME'] == L2TD_DPDK_LAN:
            if internal_network_ipversion == 6 : 
                e['l2td01_internal_dpdk_ip']    = ip_config[vm_ids['L2TD1']][interface]['ipv6']['IP']
                e['l2td02_internal_dpdk_ip']    = ip_config[vm_ids['L2TD2']][interface]['ipv6']['IP']
                e['l2td_internal_dpdk_cipa_ip'] = ip_config[vm_ids['L2TD1']][interface]['IPALIAS'][0]
            else: 
                e['l2td01_internal_dpdk_ip']    = ip_config[vm_ids['L2TD1']][interface]['ipv4']['IP']
                e['l2td02_internal_dpdk_ip']    = ip_config[vm_ids['L2TD2']][interface]['ipv4']['IP']
                e['l2td_internal_dpdk_cipa_ip'] = ip_config[vm_ids['L2TD1']][interface]['IPALIAS'][0]
    e.update(get_hc_ne_specific_extension_details(no_of_tdcore,'TD_Core','tdcore'))
    e.update(get_hc_ne_specific_extension_details(no_of_tdgm,'TD_Gm','tdgm'))
    if enable_tddia == "yes":
        e.update(get_hc_ne_specific_extension_details(no_of_tddia,'TD_Dia','tddia'))
    return e

def get_hc_nk_ne_specific_extension_details(no_of_nodes,nodetype,extension_var_name):
    global CSCF_DPDK_LAN
    e = dict()
    if no_of_nodes < 1:
        print "%s NE not present..continuing" %nodetype
        return e
    e['%s_dpdk_ips' %extension_var_name] = []
    e['%s_internal_ips'%extension_var_name] = []
    e['%s_names'%extension_var_name] = []
    e['%s_uuids'%extension_var_name] = []
    for k in range(no_of_nodes):
        core_node1 = "%s%s" %(nodetype,k * 1 + 1)
        core01 = vm_ids[core_node1]
        if dpdk_enabled(vm_ids[core_node1]):
            for interface in ip_config[core01].keys():
                if ip_config[core01][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
                        if internal_network_ipversion == 6 : 
                            e['%s_dpdk_ips' %extension_var_name].append(ip_config[core01][interface]['ipv6']['IP'])
                        else:
                            e['%s_dpdk_ips' %extension_var_name].append(ip_config[core01][interface]['ipv4']['IP'])
        e['%s_internal_ips'%extension_var_name].append(vms[core01]['NodeIp'])
        if node == 'nodename':
            e['%s_names'%extension_var_name].append(vms[core01]['NodeName'])
        else:
            e['%s_names'%extension_var_name].append(core01)
        e['%s_uuids'%extension_var_name].append(vms[core01]['Uuid'])
    return e

def create_hc_nk_cscf_extension():
    global node,l2td_iface_list,no_of_cscf,no_of_tdcore,no_of_tdgm,CSCF_DPDK_LAN,L2TD_DPDK_LAN
    e = dict()
    e.update(get_lb_cif_extension_detais())
    e.update( {
    'l2td01_internal_ip'          : vms[vm_ids['L2TD1']]['NodeIp'],
    'l2td02_internal_ip'          : vms[vm_ids['L2TD2']]['NodeIp'],
    'l2td01_uuid'                 : vms[vm_ids['L2TD1']]['Uuid'],
    'l2td02_uuid'                 : vms[vm_ids['L2TD2']]['Uuid'],
    'cdi01_internal_ip'          : vms[vm_ids['CDI1']]['NodeIp'],
    'cdi02_internal_ip'          : vms[vm_ids['CDI2']]['NodeIp'],
    'cdi_internal_cipa_ip'       : ip_config[vm_ids['CDI1']]['eth0']['IPALIAS'][0],
    'cdi01_uuid'                 : vms[vm_ids['CDI1']]['Uuid'],
    'cdi02_uuid'                 : vms[vm_ids['CDI2']]['Uuid'],
    })
    e['l2td_internal_cipa_ip'] = calculate_l2td_internal_cipa_ip(internal_network_cidr)
    l2td_iface_list = natural_sort(ip_config[vm_ids['L2TD1']].keys())
    e['l2td_vnic_count'] = int(re.split('([0-9]+)', l2td_iface_list[-1])[1]) + 1
    if node == 'nodename':
        e.update(
              {
                'l2td01_name'                 : vms[vm_ids['L2TD1']]['NodeName'],
                'l2td02_name'                 : vms[vm_ids['L2TD2']]['NodeName'],
                'cdi01_name'                 : vms[vm_ids['CDI1']]['NodeName'],
                'cdi02_name'                 : vms[vm_ids['CDI2']]['NodeName']
              })
    else:
        e.update(
              {
                'l2td01_name'                 : vm_ids['L2TD1'],
                'l2td02_name'                 : vm_ids['L2TD2'],
                'cdi01_name'                : vm_ids['CDI1'],
                'cdi02_name'                : vm_ids['CDI2']
              })

    no_of_tdcore = number_occurance("TD_Core")
    no_of_tdgm = number_occurance("TD_Gm")
    if enable_tddia == "yes":
        no_of_tddia = number_occurance("TD_Dia")
    no_of_cscf = number_occurance("CSCF")
    # if dpdk_enabled(vm_ids['CSCF1']) and roles not in ['hc_nk_si','hc_nk_all'] and no_of_tdgm == 0:
        # e['cscf_dpdk_ips'] = []
    e['cscf_internal_ips'] = []
    e['cscf_names'] = []
    e['cscf_uuids'] = []

    for k in range(no_of_cscf):
        cscf_node = "CSCF%s" %(k * 1 + 1)
        cscf01 = vm_ids[cscf_node]
        # if dpdk_enabled(vm_ids['CSCF1']) and roles not in ['hc_nk_si','hc_nk_all'] and no_of_gm == 0:
        #     for interface in ip_config[cscf01].keys():
        #         if ip_config[cscf01][interface]['LAN_NAME'] == CSCF_DPDK_LAN:
        #                 if internal_network_ipversion == 6 : 
        #                     e['cscf_dpdk_ips'].append(ip_config[cscf01][interface]['ipv6']['IP'])
        #                 else:
        #                     e['cscf_dpdk_ips'].append(ip_config[cscf01][interface]['ipv4']['IP'])
        e['cscf_internal_ips'].append(vms[cscf01]['NodeIp'])
        if node == 'nodename':
            e['cscf_names'].append(vms[cscf01]['NodeName'])
        else:
            e['cscf_names'].append(cscf01)
        e['cscf_uuids'].append(vms[cscf01]['Uuid'])

    for interface in ip_config[vm_ids['L2TD1']].keys():
        if ip_config[vm_ids['L2TD1']][interface]['LAN_NAME'] == L2TD_DPDK_LAN:
            if internal_network_ipversion == 6 : 
                e['l2td01_internal_dpdk_ip']    = ip_config[vm_ids['L2TD1']][interface]['ipv6']['IP']
                e['l2td02_internal_dpdk_ip']    = ip_config[vm_ids['L2TD2']][interface]['ipv6']['IP']
                e['l2td_internal_dpdk_cipa_ip'] = ip_config[vm_ids['L2TD1']][interface]['IPALIAS'][0]
            else: 
                e['l2td01_internal_dpdk_ip']    = ip_config[vm_ids['L2TD1']][interface]['ipv4']['IP']
                e['l2td02_internal_dpdk_ip']    = ip_config[vm_ids['L2TD2']][interface]['ipv4']['IP']
                e['l2td_internal_dpdk_cipa_ip'] = ip_config[vm_ids['L2TD1']][interface]['IPALIAS'][0]

    e.update(get_hc_nk_ne_specific_extension_details(no_of_tdcore,'TD_Core','tdcore'))
    e.update(get_hc_nk_ne_specific_extension_details(no_of_tdgm,'TD_Gm','tdgm'))
    if enable_tddia == "yes":
        e.update(get_hc_nk_ne_specific_extension_details(no_of_tddia,'TD_Dia','tddia'))
    return e    

def lan_ip_mapping(nets,netype):
    global cscf_iface_list,lb_iface_list,cif_iface_list,oam_iface_list,cscf_ip_details,lb_ip_details,oam_ip_details,cdi_ip_details,l2td_ip_details
    if netype == "CSCF": iface = cscf_iface_list
    if netype == "LB": iface = lb_iface_list
    if netype == "CIF": iface = cif_iface_list
    if netype == "OAMUnit": iface = oam_iface_list
    if netype == "L2TD": iface = l2td_iface_list
    if netype == "CDI": iface = tdcore_iface_list
    # if netype == "TDCORE": iface = tdcore_iface_list

    for interface in iface:
        if netype == "LB":
            lbcpd = {}
            lbcpd[interface] = {}
            lbcpd[interface]["cpdId"] = []
            lbcpd[interface]["cpdId"].append({"cpdId": "lbCpd%s" %(interface), "addresses": []})
            for lbnode in ip_details['LB'].keys():
               lbcpd[interface]["cpdId"][0]["addresses"].append({"ip": ip_details['LB'][lbnode][interface]['IP']})
            if ip_config[vm_ids["LB1"]][interface]['IPALIAS']:
                lbcpd[interface]["cpdId"].append({"cpdId":"lbMovingCpd%s" %(interface),"addresses": []})
                for lbnode in ip_details['LB'].keys():
                    for ipalias_ip in ip_details['LB'][lbnode][interface]['IPALIAS']:
                        if ipalias_ip !="": lbcpd[interface]["cpdId"][1]["addresses"].append({"ip": ipalias_ip})
            lb_ip_details.append(lbcpd)

        if netype == "CIF":
            cifcpd = {}
            cifcpd[interface] = {}
            cifcpd[interface]["cpdId"] = []
            cifcpd[interface]["cpdId"].append({"cpdId": "cifCpd%s" %(interface), "addresses": []})
            for cifnode in ip_details['CIF'].keys():
               cifcpd[interface]["cpdId"][0]["addresses"].append({"ip": ip_details['CIF'][cifnode][interface]['IP']})
            if ip_config[vm_ids["CIF1"]][interface]['IPALIAS']:
                cifcpd[interface]["cpdId"].append({"cpdId":"cifMovingCpd%s" %(interface),"addresses": []})
                for cifnode in ip_details['CIF'].keys():
                    for ipalias_ip in ip_details['CIF'][cifnode][interface]['IPALIAS']:
                        if ipalias_ip !="": cifcpd[interface]["cpdId"][1]["addresses"].append({"ip": ipalias_ip})
            cif_ip_details.append(cifcpd)

        if netype == "OAMUnit":
            oamcpd = {}
            oamcpd[interface] = {}
            oamcpd[interface]["cpdId"] = []
            oamcpd[interface]["cpdId"].append({"cpdId":"oamCpd%s" %(interface),"addresses": []})
            for oamnode in ip_details['OAMUnit'].keys():
               oamcpd[interface]["cpdId"][0]["addresses"].append({"ip": ip_details['OAMUnit'][oamnode][interface]['IP']})
            if ip_config[vm_ids["OAMUnit"]][interface]['IPALIAS']:
                oamcpd[interface]["cpdId"].append({"cpdId":"oamMovingCpd%s" %(interface),"addresses": []})
                for oamnode in ip_details['OAMUnit'].keys():
                    for ipalias_ip in ip_details['OAMUnit'][oamnode][interface]['IPALIAS']:
                        if ipalias_ip !="": oamcpd[interface]["cpdId"][1]["addresses"].append({"ip": ipalias_ip})
            oam_ip_details.append(oamcpd)

        if netype == "L2TD":
            l2tdcpd = {}
            l2tdcpd[interface] = {}
            l2tdcpd[interface]["cpdId"] = []
            l2tdcpd[interface]["cpdId"].append({"cpdId":"l2tdCpd%s" %(interface),"addresses":[]})
            for l2tdnode in ip_details['L2TD'].keys():
               l2tdcpd[interface]['cpdId'][0]["addresses"].append({"ip": ip_details['L2TD'][l2tdnode][interface]['IP']})
            if ip_config[vm_ids["L2TD1"]][interface]['IPALIAS']:
                l2tdcpd[interface]["cpdId"].append({"cpdId":"l2tdMovingCpd%s" %(interface),"addresses":[]})
                for l2tdnode in ip_details['L2TD'].keys():
                    for ipalias_ip in ip_details['L2TD'][l2tdnode][interface]['IPALIAS']:
                        if ipalias_ip !="": l2tdcpd[interface]["cpdId"][1]["addresses"].append({"ip": ipalias_ip})
            l2td_ip_details.append(l2tdcpd)

        if netype == "CDI":
            cdicpd = {}
            cdicpd[interface] = {}
            cdicpd[interface]["cpdId"] = []
            cdicpd[interface]["cpdId"].append({"cpdId":"cdiCpd%s" %(interface),"addresses":[]})
            for cdinode in ip_details['CDI'].keys():
               cdicpd[interface]['cpdId'][0]["addresses"].append({"ip": ip_details['CDI'][cdinode][interface]['IP']})
            if ip_config[vm_ids["CDI1"]][interface]['IPALIAS']:
                cdicpd[interface]["cpdId"].append({"cpdId":"cdiMovingCpd%s" %(interface),"addresses":[]})
                for cdinode in ip_details['CDI'].keys():
                    for ipalias_ip in ip_details['CDI'][cdinode][interface]['IPALIAS']:
                        if ipalias_ip !="": cdicpd[interface]["cpdId"][1]["addresses"].append({"ip": ipalias_ip})
            cdi_ip_details.append(cdicpd)

def get_ne_specific_ip_details(no_of_nodes,node_iface_list,nodetype):
    global cscf_iface_list,lb_iface_list,oam_iface_list,l2td_iface_list,tdcore_iface_list,ip_details,\
                cdi_iface_list
    e = dict()
    if no_of_nodes < 1:
        print "%s NE not present..continuing" %nodetype
        return e
    e[nodetype] = {}
    globals()[node_iface_list] = natural_sort(ip_config[vm_ids['%s2' %nodetype]].keys())  
    for k in range(no_of_nodes):
        e[nodetype][k + 1] = {}
        if 'OAMUnit' in nodetype and k == 0:
            c = 'OAMUnit'
        else:  
            c = "%s%s" %(nodetype,k * 1 + 1)
        for interface in globals()[node_iface_list]:
            e[nodetype][k + 1][interface] = {}
            if 'IP' in ip_config[vm_ids[c]][interface]['ipv4'] and ip_config[vm_ids[c]][interface]['ipv4']['IP']:
                e[nodetype][k + 1][interface]['IP'] = ip_config[vm_ids[c]][interface]['ipv4']['IP']
            else:
                e[nodetype][k + 1][interface]['IP'] = ip_config[vm_ids[c]][interface]['ipv6']['IP']
            if ip_config[vm_ids[c]][interface]['IPALIAS']:
                e[nodetype][k + 1][interface]['IPALIAS'] = ip_config[vm_ids[c]][interface]['IPALIAS']
    return e

def create_cbam_input_env():
    global cscf_iface_list,lb_iface_list,oam_iface_list,l2td_iface_list,tdcore_iface_list,ip_details,\
                cdi_iface_list,no_of_cscf,no_of_tdcore,cif_iface_list
    e = dict()
    e.update(get_ne_specific_ip_details(no_of_cscf,'cscf_iface_list','CSCF'))
    e.update(get_ne_specific_ip_details(3,'oam_iface_list','OAMUnit'))
    if roles in ['si','all']:
        e.update(get_ne_specific_ip_details(2,'lb_iface_list','LB'))
    if roles in ["hc_all","hc_si","hc_nk_si","hc_nk_all"]:
        e.update(get_ne_specific_ip_details(2,'cif_iface_list','CIF'))
        e.update(get_ne_specific_ip_details(2,'l2td_iface_list','L2TD'))
        e.update(get_ne_specific_ip_details(no_of_tdcore,'tdcore_iface_list','TD_Core'))
    if roles in ["hc_nk_si","hc_nk_all"]:
        e.update(get_ne_specific_ip_details(2,'cdi_iface_list','CDI'))
    ip_details = e
    return ip_details

def check_invalid_lan_configuration(nets,iface_list,type):
    status = False
    for iface in nets.keys():
        if iface not in iface_list:
            logger.info("!!!WARNING:Invalid LAN configuration used in TPD,%s interface missing for %s node" %(iface,type))
            print "!!!WARNING:Invalid LAN configuration used in TPD,%s interface missing for %s node" %(iface,type)
            status = True
    return status

def create_cbam_extension_env():
    global node,enable_tddia
    if vm_ids['OAMUnit'] != vms[vm_ids['OAMUnit']]['NodeName']: 
        logger.info("Nodenames and Vmnames are not same, it is recommended to keep the same name for both Nodename and VMname")
        print "-------------------------------------------------------------------------------------------------------"
        print "Nodenames and Vmnames are not same,It is recommended to keep the same name for both Nodename and VMname"
        while True:
            print "Which one should be used!!! NodeName or Vmname?[select 1 or 2]"
            print "1: NodeName( %s )" %vms[vm_ids['OAMUnit']]['NodeName']
            print "2: Vmname( %s )" %vm_ids['OAMUnit']
            node = raw_input().strip('\n')
            if not (node in ['1','2']):
                print "Invalid input provided"
                sys.exit(1)
            else:
                if '1' in node : node = 'nodename'
                else: node = 'vmname'
                break
    e = common_extension_parameters()
    if roles in ["all","si"]:
        e.update(create_cscf_cbam_extension())
    elif roles in ["hc_si","hc_all"]:
        if query_yes_no("TD diamter vm exists?"):
            enable_tddia = 'yes'
        else:
            enable_tddia = 'no'
        e.update(create_hc_cscf_extension())
    elif roles in ["hc_nk_si","hc_nk_all"]:
        if query_yes_no("TD diamter vm exists?"):
            enable_tddia = 'yes'
        else:
            enable_tddia = 'no'
        e.update(create_hc_nk_cscf_extension())
    return e

def write_cbam_extension_env():
    env = {}
    env = create_cbam_extension_env()
    if enable_aif == 'yes':
        get_aif()
        env.update(aif)
        logger.info("AIF Details :\n %s " %aif)
    js = {}
    js['extensions'] = []
    for i in env:
        js['extensions'].append({"name": i, "value": env[i]})
    f = open(EXTENSION_FILE, "w")
    f.write(json.dumps(js,indent=2))
    f.close()
    print "############################################################################################"
    print "\"%s\" extension file written successfully" % (EXTENSION_FILE)
    print "#############################################################################################\n"

def get_cbam_extcps(ne_nets,ne_iface_list,ne_ip_details,network):
    for iface in ne_nets.keys():
        if ne_nets[iface]["value"] not in network.keys():
            network[ne_nets[iface]["value"]] = {}
            network[ne_nets[iface]["value"]]["extCps"] = []
            network[ne_nets[iface]["value"]]["resourceId"] = ne_nets[iface]["value"]
        if iface in ne_iface_list:
            for ips in ne_ip_details:
                if iface in ips.keys():
                    for extcps in ips[iface]['cpdId']: network[ne_nets[iface]["value"]]["extCps"].append(extcps)
                    # network[ne_nets[iface]["value"]]["extCps"].append(ips[iface])
        else:
            logger.info("!!!NOTE:Replace %s network in %s file with dummy network created in the cloud" %(ne_nets[iface]["value"],INPUT_FILE))
            print "!!!NOTE:Replace %s network in %s file with dummy network created in the cloud" %(ne_nets[iface]["value"],INPUT_FILE)
            network[ne_nets[iface]["value"]]["extCps"] = []
            network[ne_nets[iface]["value"]]["extCps"].append({"cpdId":"","addresses":[{"ip": ""}]})
    return network

def ask_user_answer_for_continue(status):
    if status:
        logger.info("!!!WARNING:It is highly recommended to use the proper lan configuration in TPD")
        print "!!!WARNING:It is highly recommended to use the proper lan configuration in TPD"
        if not (query_yes_no("Do you want to continue with Dummy networks?")):
            sys.exit(1)
        print ("\n")

def add_dummy_missing_interfaces(node_interface_list,ne_nets,internal_iface_list,nodetype):
    last_interface = int(re.split('([0-9]+)', node_interface_list[-1])[1])
    for interface_id in range(last_interface):
        interface = "eth%s" % interface_id
        if interface not in internal_iface_list and interface not in ne_nets.keys():
            ne_nets[interface] = {"key":"Dummy%s%s" %(nodetype,interface),"value":"<Dummy%s%s>" %(nodetype,interface)}
    return ne_nets

def write_cbam_input_env():
    global cscf_iface_list,lb_iface_list,oam_iface_list,l2td_iface_list,tdcore_iface_list,cdi_iface_list,cloud_params,enable_aif
    ip_details = {}
    ip_details = create_cbam_input_env()
    js = {}
    cloud_params["flavourId"] = "cscf_%s" %roles.strip('_all')
    extended_cloud_params = ({"additionalParams":{
                                                    "aif" : enable_aif
                                                  }
                             })
    js = cloud_params
    js.update(extended_cloud_params)
    if roles in ["all","si"]:
        js.update(cloud_flavours_cscf)
    elif roles in ["hc_all","hc_si"]:
        js.update(cloud_flavour_hc_cscf)
    elif roles in  ["hc_nk_si","hc_nk_all"]:
        js.update(cloud_flavour_hc_nk_cscf)
    js['extVirtualLinks'] = []
    ext_links = []

    if roles in ['all','si']:
        lb_nets = {"eth1":{"key":"oam_lan","value":"<OAM_lan>"}}
        for interface in lb_iface_list:
            if 'all' in roles and "eth0" not in interface and "eth2" not in interface and interface not in lb_nets.keys():
                key = "LAN%s" %(interface)
                lb_nets[interface] = {"key":key,"value":"<%s>" % ip_config[vm_ids['LB1']][interface]['LAN_NAME']}
            elif 'si' in roles and "eth0" not in interface and interface not in lb_nets.keys():
                key = "LAN%s" %(interface)
                lb_nets[interface] = {"key":key,"value":"<%s>" % ip_config[vm_ids['LB1']][interface]['LAN_NAME']}
        if 'all' in roles : lb_nets.update(add_dummy_missing_interfaces(lb_iface_list,lb_nets,['eth0','eth2'],"LB"))
        if 'si' in roles : lb_nets.update(add_dummy_missing_interfaces(lb_iface_list,lb_nets,['eth0'],"LB"))
    else:
        cif_nets = {"eth1":{"key":"oam_lan","value":"<OAM_lan>"}}
        for interface in cif_iface_list:
            if "eth0" not in interface and interface not in cif_nets.keys():
                key = "LAN%s" %(interface)
                cif_nets[interface] = {"key":key,"value":"<%s>" % ip_config[vm_ids['CIF1']][interface]['LAN_NAME']}
        cif_nets.update(add_dummy_missing_interfaces(cif_iface_list,cif_nets,['eth0'],"LB"))

    if roles in  ["hc_all","hc_si","hc_nk_si","hc_nk_all"]:
        l2td_nets = {}
        for interface in l2td_iface_list:
            if "eth0" not in interface and  "eth1" not in interface:
                key = "LAN%s" %(interface)
                l2td_nets[interface] = {"key":key,"value":"<%s>" % ip_config[vm_ids['L2TD1']][interface]['LAN_NAME']}
        l2td_nets.update(add_dummy_missing_interfaces(l2td_iface_list,l2td_nets,['eth0','eth1'],"LB"))

    if roles in  ["hc_nk_si","hc_nk_all"]:
        cdi_nets = {}
        for interface in cdi_iface_list:
            if "eth0" not in interface:
                key = "LAN%s" %interface
                cdi_nets[interface] = {"key":key,"value":"<%s>" % ip_config[vm_ids['CDI1']][interface]['LAN_NAME']}
        cdi_nets.update(add_dummy_missing_interfaces(cdi_iface_list,cdi_nets,['eth0'],"LB"))

    oam_nets = {"eth1":{"key":"oam_lan","value":"<OAM_lan>"}}

    network = {}
    lan_ip_mapping(oam_nets,"OAMUnit")
    network.update(get_cbam_extcps(oam_nets,oam_iface_list,oam_ip_details,network))

    if roles in ['si','all']:
        lan_ip_mapping(lb_nets,"LB")
        status = check_invalid_lan_configuration(lb_nets,lb_iface_list,"LB")
        ask_user_answer_for_continue(status)
        network.update(get_cbam_extcps(lb_nets,lb_iface_list,lb_ip_details,network))
    elif roles in ["hc_all","hc_si","hc_nk_si","hc_nk_all"]: 
        status = check_invalid_lan_configuration(cif_nets,cif_iface_list,"CIF")
        ask_user_answer_for_continue(status)
        status = check_invalid_lan_configuration(l2td_nets,l2td_iface_list,"L2TD")
        ask_user_answer_for_continue(status)

    if roles in ["hc_all","hc_si","hc_nk_si","hc_nk_all"]:
        lan_ip_mapping(cif_nets,"CIF")
        network.update(get_cbam_extcps(cif_nets,cif_iface_list,cif_ip_details,network))
        lan_ip_mapping(l2td_nets,"L2TD")
        network.update(get_cbam_extcps(l2td_nets,l2td_iface_list,l2td_ip_details,network))

    if roles in ["hc_nk_si","hc_nk_all"]: 
        lan_ip_mapping(cdi_nets,"CDI")
        network.update(get_cbam_extcps(cdi_nets,cdi_iface_list,cdi_ip_details,network))

    for net in network.keys():
        js['extVirtualLinks'].append(network[net])

    f = open(INPUT_FILE, "w")
    f.write(json.dumps(js,indent=2))
    f.close()
    print "###########################################################################################################################"
    print "Wrote \"%s\" file ,update the cloud parameters in the section flavourId,softwareImages,vims,computeResourceFlavours details." % (INPUT_FILE)
    print "###########################################################################################################################"

def check_for_empty_parameters_in_input_file():
    validate_dict = {}
    empty_value_variable = []
    with open(EXTENSION_FILE, 'r') as f:
        validate = json.load(f)
    for listindex in range(len(validate['extensions'])):
        if not validate['extensions'][listindex]["value"]:
            empty_value_variable.append(validate['extensions'][listindex]["name"])
    return empty_value_variable

def parse_args():
    parser = argparse.ArgumentParser(description="Create CSCF ENV")
    parser.add_argument("-d", help="enable debug", action="store_true")
    parser.add_argument("--roles", help="(cscf_all/cscf_si/cscf_hc_si/cscf_hc_all/cscf_hc_nk_si/cscf_hc_nk_all)",required=True)
    parser.add_argument("--dn", help="DN name", required=True)
    parser.add_argument("--du", help="DU name", required=True)
    parser.add_argument("--repo-ip", help="CMRepo IP", required=True)
    parser.add_argument("--cmuser",  help="CM user name")
    parser.add_argument("--password", help="CM user password")
    args = parser.parse_args()
    if (args.cmuser and not args.password) or (args.password and not args.cmuser):
        parser.print_help()
        sys.exit()
    return args


if __name__ == "__main__":
    args = parse_args()
    if ":" in  args.repo_ip:
        repo_ip = "[%s]" % args.repo_ip
    else:
        repo_ip = args.repo_ip  
    dn = args.dn
    du = args.du
    if args.cmuser and args.password :
        username = args.cmuser
        password = args.password
    if args.d:
        DEBUG = True

    roles_list = ['cscf_all','cscf_si','cscf_hc_si','cscf_hc_all','cscf_hc_nk_si','cscf_hc_nk_all']
    if args.roles not in roles_list:
        print "\nERROR:!!! Invalid CSCF role: Select from %s" %roles_list
        sys.exit(1)
    roles = args.roles.split('cscf_')[1]
        
    print "Getting deployment metadata from repo..."
    get_deploy_params()
    print "Getting VM IDs from repo..."
    get_vm_ids()
    print "Getting IP/LAN configuration from repo..."
    get_ip_config()
    write_cbam_extension_env()
    write_cbam_input_env()
    empty_parameter_list = check_for_empty_parameters_in_input_file()
    if empty_parameter_list:
        print "Fill these parameters %s in %s file" % (empty_parameter_list,EXTENSION_FILE)
